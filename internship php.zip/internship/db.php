<?php
mysql_connect('localhost','test','Asdf@1234');
mysql_select_db("test");

?>